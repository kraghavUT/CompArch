#!/usr/bin/sh
gcc -o assembler assembler.c
gcc -o simulator simulator.c