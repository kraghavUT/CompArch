#!/usr/bin/sh
gcc -o hw2 HW2.c -lm
